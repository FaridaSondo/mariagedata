# =============================================================================
# Comprehensive Statistical Analysis of Divorce Probability Factors
# Purpose: Analyze the relationship between divorce probability and various factors
# Author: Statistical Analysis Team
# Last Updated: 2024
# =============================================================================

# Part 1: Environment Setup and Package Management
# -----------------------------------------------------------------------------
# This function handles package installation and loading, with error checking
install_and_load_packages <- function(packages) {
  for (package in packages) {
    if (!require(package, character.only = TRUE)) {
      tryCatch({
        install.packages(package)
        library(package, character.only = TRUE)
      }, error = function(e) {
        message(sprintf("Failed to install/load package: %s\nError: %s", package, e))
      })
    }
  }
}

# Define all necessary packages with their specific purposes
required_packages <- c(
  "tidyverse",   # For data manipulation and visualization
  "corrplot",    # For correlation analysis
  "car",         # For VIF analysis
  "lmtest",      # For regression diagnostics
  "stats",       # For statistical functions
  "ggplot2",     # For enhanced visualizations
  "gridExtra",   # For arranging multiple plots
  "grid"         # For advanced plotting features
)

# Load all required packages
install_and_load_packages(required_packages)

# Part 2: Data Loading and Preparation
# -----------------------------------------------------------------------------
# Read the dataset with error handling
load_data <- function(file_path) {
  tryCatch({
    read.csv(file_path)
  }, error = function(e) {
    stop(sprintf("Error reading file: %s\nPlease check the file path and format.", e))
  })
}

data <- load_data("F:/Downloads/Data_project/Marriage_Divorce_DB.csv")

# Define variable mappings for clearer presentation
variable_mapping <- list(
  "DP" = "Divorce.Probability",
  "GI" = "Good.Income",
  "AG" = "Age.Gap",
  "ED" = "Education",
  "FR" = "Relationship.with.the.Spouse.Family"
)

# Get variables of interest
variables_of_interest <- unlist(variable_mapping)

# Part 3: Custom Theme Definition
# -----------------------------------------------------------------------------
# Create a consistent theme for all visualizations
theme_custom <- theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    axis.title = element_text(size = 12),
    axis.text = element_text(size = 10),
    plot.margin = margin(15, 15, 15, 15),
    legend.position = "bottom",
    strip.text = element_text(size = 12, face = "bold"),
    panel.grid.minor = element_blank()
  )

# Part 4: Initial Statistical Analysis
# -----------------------------------------------------------------------------
# Generate and display summary statistics
summary_stats <- summary(data[variables_of_interest])
print("Summary Statistics of Key Variables:")
print(summary_stats)

# Calculate correlation matrix with abbreviated names
correlation_matrix <- cor(data[variables_of_interest])
colnames(correlation_matrix) <- names(variable_mapping)
rownames(correlation_matrix) <- names(variable_mapping)

# Part 5: Enhanced Visualizations
# -----------------------------------------------------------------------------
# Create correlation plot with improved readability
corrplot(correlation_matrix, 
         method = "color",
         type = "upper",
         addCoef.col = "black",
         tl.col = "black",
         tl.srt = 45,
         tl.cex = 1.2,
         title = "Correlation Matrix of Divorce Factors",
         mar = c(0,0,2,0),
         col = colorRampPalette(c("#6D9EC1", "white", "#E46726"))(200))

# Function to create standardized scatter plots
create_scatter_plot <- function(data, x_var, y_var, x_label, title) {
  ggplot(data, aes_string(x = x_var, y = y_var)) +
    geom_point(alpha = 0.6, color = "#2C3E50") +
    geom_smooth(method = "lm", color = "#E74C3C", se = TRUE) +
    theme_custom +
    labs(title = title,
         x = x_label,
         y = "Divorce Probability") +
    scale_x_continuous(labels = scales::number_format(accuracy = 0.1))
}

# Create individual scatter plots with improved aesthetics
p1 <- create_scatter_plot(data, "Good.Income", "Divorce.Probability", 
                          "Income", "Income vs Divorce Prob.")
p2 <- create_scatter_plot(data, "Age.Gap", "Divorce.Probability", 
                          "Age Gap", "Age Gap vs Divorce Prob.")
p3 <- create_scatter_plot(data, "Education", "Divorce.Probability", 
                          "Education", "Education vs Divorce Prob.")
p4 <- create_scatter_plot(data, "Relationship.with.the.Spouse.Family", 
                          "Divorce.Probability", "Family Relationship",
                          "Family Rel. vs Divorce Prob.")

# Arrange scatter plots with improved layout and title
title <- grid::textGrob("Relationships with Divorce Probability", 
                        gp = grid::gpar(fontsize = 16, fontface = "bold"))
grid.arrange(p1, p2, p3, p4, ncol = 2, top = title)

# Part 6: Regression Analysis
# -----------------------------------------------------------------------------
# Fit multiple linear regression model
model <- lm(Divorce.Probability ~ Good.Income + Age.Gap + Education + 
              Relationship.with.the.Spouse.Family, data = data)

# Calculate diagnostic measures
vif_values <- vif(model)
bp_test <- bptest(model)

# Create diagnostic plots
par(mfrow = c(2,2), mar = c(4,4,3,2))
plot(model)
par(mfrow = c(1,1))

# Create density plot for divorce probability distribution
ggplot(data, aes(x = Divorce.Probability)) +
  geom_density(fill = "#3498DB", alpha = 0.7) +
  theme_custom +
  labs(title = "Distribution of Divorce Probability",
       x = "Divorce Probability",
       y = "Density")

# Part 7: Comprehensive Results Summary
# -----------------------------------------------------------------------------
summarize_results <- function(model, correlation_matrix, vif_values, bp_test) {
  cat("\nCOMPREHENSIVE ANALYSIS RESULTS")
  cat("\n============================\n\n")
  
  # Model Performance Metrics
  cat("1. Model Performance Metrics:\n")
  cat("   • R-squared:", round(summary(model)$r.squared, 4), "\n")
  cat("   • Adjusted R-squared:", round(summary(model)$adj.r.squared, 4), "\n")
  cat("   • F-statistic:", round(summary(model)$fstatistic[1], 2), "\n")
  cat("   • Overall p-value:", sprintf("%.4e", 
                                       pf(summary(model)$fstatistic[1], 
                                          summary(model)$fstatistic[2], 
                                          summary(model)$fstatistic[3], 
                                          lower.tail = FALSE)), "\n\n")
  
  # Variable Effects
  cat("2. Individual Variable Effects:\n")
  coef_table <- summary(model)$coefficients
  for(var in rownames(coef_table)) {
    cat("   ", gsub("\\.", " ", var), ":\n")
    cat("      • Coefficient:", round(coef_table[var, "Estimate"], 4), "\n")
    cat("      • Std. Error:", round(coef_table[var, "Std. Error"], 4), "\n")
    cat("      • t-value:", round(coef_table[var, "t value"], 4), "\n")
    cat("      • p-value:", sprintf("%.4e", coef_table[var, "Pr(>|t|)"]), "\n\n")
  }
  
  # Correlation Analysis
  cat("3. Key Correlations with Divorce Probability:\n")
  correlations <- correlation_matrix[1, -1]
  for(var in names(correlations)) {
    cat("   •", var, "(", gsub("\\.", " ", variable_mapping[[var]]), "):", 
        round(correlations[var], 4), "\n")
  }
  cat("\n")
  
  # Model Diagnostics
  cat("4. Model Diagnostics:\n")
  cat("   A. Multicollinearity Check (VIF Values):\n")
  for(var in names(vif_values)) {
    cat("      •", gsub("\\.", " ", var), ":", round(vif_values[var], 4), "\n")
  }
  cat("\n   B. Heteroscedasticity Test:\n")
  cat("      • Breusch-Pagan test p-value:", sprintf("%.4e", bp_test$p.value), "\n")
}

# Generate and display comprehensive results
summarize_results(model, correlation_matrix, vif_values, bp_test)

# Display variable abbreviation legend
cat("\nVariable Abbreviations Legend:")
cat("\n---------------------------")
for(short_name in names(variable_mapping)) {
  cat("\n", short_name, "=", gsub("\\.", " ", variable_mapping[[short_name]]))
}

